export const Paleta ={
    primary: '#253C98',
    secondary: '#EE2D78',
    primarybg: '#F0F2E9',
    complementaryorange: '#F99D2D',
    complementarygreen: '#89C540'
}