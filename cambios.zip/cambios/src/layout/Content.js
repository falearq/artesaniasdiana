import React from 'react'
import styled from 'styled-components';



const Content = () => {
    return(
<ContentWrap>

</ContentWrap> ) }


export const ContentWrap= styled.div`


`
export default Content;